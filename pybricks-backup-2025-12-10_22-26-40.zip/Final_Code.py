from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from Rotas import Rota_1, Rota_2, Rota_3, Rota_4

Rota_1()
Rota_2()
# Rota_3()
# Rota_4()
