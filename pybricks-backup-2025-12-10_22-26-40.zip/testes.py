from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop, Axis
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from Drive_Train import aguardar_calibrar_imu, andar, rotate, rodar
from consts import (
    Open, close, low, upper, deposit,
    cancela_direita, cancela_esquerda,
    volta_esquerda, volta_direita,
    direita_direto, esquerda_direto
)
from Trains import Trem1, Trem2, Trem3, Trem4
from Boxes import Gbox, Bbox

hub = PrimeHub(top_side=Axis.X, front_side=Axis.Z)

cs_dir = ColorSensor(Port.E) # Use o sensor que está dando problema




#312-320, reflexao 36, color white
#225-226, reflexao 27, color blue
#149, reflexao 35, color green


while True:
    # O sensor.hsv() retorna (Hue, Saturation, Value)
    hsv = cs_dir.hsv()
    cor_pybricks = cs_dir.color()
    print(f"HUE: {hsv[0]} | REFLEXÃO: {cs_dir.reflection()} | COR: {cor_pybricks}")
    wait(500)
    print("--- TESTE DE TONALIDADE (HUE) ---")
    volts_mv = hub.battery.voltage()
    volts = volts_mv / 1000
    hub.display.text(f"{volts:.2}V")
    wait
