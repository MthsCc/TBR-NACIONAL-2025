from pybricks.hubs import PrimeHub
from pybricks.parameters import Axis
from pybricks.tools import wait
from Drive_Train import aguardar_calibrar_imu, andar, rotate, rodar, descida
from consts import (
    Open, close, low, upper, deposit,
    cancela_direita, cancela_esquerda,
    volta_esquerda, volta_direita,
    direita_direto, esquerda_direto
)
from Trains import Trem1, Trem2, Trem3, Trem4
from Boxes import Gbox, Bbox

hub = PrimeHub(top_side=Axis.X, front_side=Axis.Z)


# ==================== ROTAS PRINCIPAIS ====================

def Rota_1():
    """Rota principal 1: Inicia missão e vai para estação I."""
    aguardar_calibrar_imu()
    descida(30)
    rotate(-90)
    wait(100)
    andar(25)
    rotate(-90)
    andar(21.5)
    rotate(90)
    wait(200)
    close()
    andar(34)
    wait(200)
    cancela_esquerda()
    Trem1()
    rotate(90)


def Rota_2():
    """Rota principal 2: Vai para boxG."""
    hub.imu.reset_heading(0)
    wait(300)
    andar(10)
    rotate(-90)
    andar(32)
    rotate(90)
    wait(400)
    andar(53)
    wait(400)
    rotate(90)
    Open()
    andar(15.5)
    Gbox()


def Rota_3():
    """Rota principal 3: Vai para estações III e IV."""
    hub.imu.reset_heading(0)
    rotate(-90)
    andar(10)
    rotate(90)
    andar(40)
    rotate(-90)
    andar(20)
    rotate(-90)
    rodar(90)
    andar(10)
    wait(100)
    Open()
    cancela_direita()
    Trem4()
    rotate(-90)


def Rota_4():
    """Rota principal 4: Vai para boxB."""
    hub.imu.reset_heading(0)
    andar(40)
    Bbox()
    andar(40)
    rotate(-90)
    andar(30)


# ==================== ROTAS SECUNDÁRIAS ====================

def route_I():
    """Rota I: Movimento inicial para pegar carrinho."""
    andar(25)
    close()
    rotate(-90)
    andar(31)


def route_II():
    """Rota II: Movimento após pegar carrinho."""
    rotate(65)
    andar(59)
    wait(100)
    rotate(97)
    wait(300)
    Open()
    wait(100)
    andar(17.5)
    wait(100)
    close()


def route_III():
    """Rota III: Movimento com ajustes de cancela."""
    andar(-22)
    wait(300)
    rotate(86)
    wait(300)
    direita_direto()
    wait(100)
    andar(-18)
    wait(200)
    rotate(23)
    wait(100)
    esquerda_direto()
    wait(400)
    andar(3)


def route_IV():
    """Rota IV: Movimento para posição de entrega."""
    close()
    andar(65)
    wait(100)


def route_V():
    """Rota V: Movimento para estação de trem."""
    rotate(-11)
    andar(34)
    rotate(-79)
    cancela_direita()
    andar(17)


# ==================== FUNÇÕES DE TREM ====================

def train_I():
    """Movimento para estação de trem I."""
    rotate(-90)
    andar(16.6)
    rotate(91)
    cancela_esquerda()
    andar(32)
    wait(600)


def train_III():
    """Movimento para estação de trem III."""
    rotate(90)
    andar(23)
    upper()
    rotate(-90)
    andar(13)
    cancela_direita()
    andar(4)
    wait(300)


# ==================== FUNÇÕES BOXG (POR COR) ====================
# Funções para levar carrinhos para boxG após detecção na estação II

def boxG_azul():
    """Leva carrinho azul para boxG."""
    wait(200)
    rotate(-90)
    andar(16)
    rotate(90)
    wait(200)
    andar(45)
    wait(100)
    rotate(-90)
    wait(100)
    andar(38)
    wait(100)
    rotate(90)
    andar(18.5)
    Open()
    wait(500)
    andar(-14.5)
    rotate(-90)


def boxG_verde():
    """Leva carrinho verde para boxG."""
    wait(200)
    rotate(-90)
    andar(16)
    rotate(90)
    wait(200)
    andar(45)
    wait(100)
    rotate(-90)
    wait(100)
    andar(35)
    wait(100)
    rotate(90)
    andar(16)
    Open()
    wait(500)
    andar(-14.5)
    rotate(-90)


def boxG_amarelo():
    """Leva carrinho amarelo para boxG."""
    wait(400)
    rotate(-90)
    andar(17)
    rotate(90)
    wait(200)
    andar(44)
    wait(100)
    rotate(-90)
    wait(100)
    andar(37.5)
    wait(100)
    rotate(90)
    andar(18.5)
    Open()
    wait(500)
    andar(-14.5)
    rotate(-90)


def boxG_cinza():
    """Leva carrinho cinza para boxG."""
    cancela_esquerda()
    wait(400)
    rotate(-25)
    andar(20)
    rotate(25)
    wait(200)
    andar(30)
    wait(100)
    rotate(-90)
    wait(100)
    volta_esquerda()
    wait(200)
    andar(45)
    wait(100)
    rotate(90)
    andar(16)
    Open()
    wait(500)
    andar(-17)
    rotate(-90)


# ==================== FUNÇÕES ROTA VI (POR COR) ====================
# Funções para executar rota VI após detecção na estação IV

def route_VI_azul():
    """Executa rota VI para carrinho azul."""
    rotate(-20)
    andar(48)
    rotate(-66)
    andar(33)
    rotate(-90)
    wait(300)
    andar(-6)
    wait(200)
    Open()
    wait(200)
    andar(6)
    wait(200)
    low()
    andar(-3.5)
    close()


def route_VI_amarelo():
    """Executa rota VI para carrinho amarelo."""
    rotate(-20)
    andar(48)
    rotate(-66)
    andar(32)
    rotate(-90)
    wait(300)
    andar(-6)
    wait(200)
    Open()
    wait(200)
    andar(7)
    wait(200)
    low()
    andar(-3.5)
    close()


def route_VI_verde():
    """Executa rota VI para carrinho verde."""
    rotate(-20)
    andar(48)
    rotate(-66)
    andar(32)
    rotate(-90)
    wait(300)
    andar(-6)
    wait(200)
    Open()
    wait(200)
    andar(7)
    wait(200)
    low()
    andar(-3.5)
    close()


def route_VI_cinza():
    """Executa rota VI para carrinho cinza."""
    rotate(-20)
    andar(48)
    rotate(-66)
    andar(32)
    rotate(-90)
    wait(300)
    andar(-6)
    wait(200)
    Open()
    wait(200)
    andar(7)
    wait(200)
    low()
    andar(-3.5)
    close()


# ==================== FUNÇÕES AUXILIARES ====================

def boxB_():
    """Leva carrinho para boxB."""
    rotate(90)
    andar(-41)
    rotate(90)
    andar(-50)
    rotate(90)
    andar(-40.1)
    Open()
    wait(100)


def park():
    """Estaciona o robô na posição final."""
    andar(-15.55)
    deposit()
    rotate(-90)
    andar(49.5)
