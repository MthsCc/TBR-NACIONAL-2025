from pybricks.pupdevices import ColorSensor
from pybricks.parameters import Color
from pybricks.tools import wait

from Drive_Train import andar, cs_dir, cs_esq, hub
from consts import deposit, volta_direita, volta_esquerda

# Constantes para detecção de cor HUE
PRETO_MAX = 15
AMARELO_MIN = 43
HUE_SATURACAO_MIN = 20

HUE_AZUL_MIN = 200
HUE_AZUL_MAX = 240 
HUE_VERDE_MIN = 120
HUE_VERDE_MAX = 180 


def get_cor_confiavel(sensor: ColorSensor) -> Color:
    """
    Detecta a cor do carrinho usando HUE e reflexão.
    Retorna: Color (BLUE, YELLOW, GREEN, GRAY, BLACK, NONE)
    """
    intensidade_reflexao = sensor.reflection()
    hsv = sensor.hsv()  # (Hue, Saturation, Value)
    hue = hsv[0]
    saturation = hsv[1]
    
    cor_detectada = Color.NONE

    # Amarelo: alta reflexão + hue entre 40-70
    if intensidade_reflexao >= AMARELO_MIN:
        if hue > 40 and hue < 85 and saturation > HUE_SATURACAO_MIN:
            cor_detectada = Color.YELLOW
        else:
            cor_detectada = Color.GRAY
    
    # Preto: baixa reflexão
    elif intensidade_reflexao <= PRETO_MAX:
        cor_detectada = Color.BLACK

    # Azul: hue entre 200-240
    elif hue >= HUE_AZUL_MIN and hue <= HUE_AZUL_MAX and saturation > HUE_SATURACAO_MIN:
        cor_detectada = Color.BLUE
    
    # Verde: hue entre 120-180
    elif hue >= HUE_VERDE_MIN and hue <= HUE_VERDE_MAX and saturation > HUE_SATURACAO_MIN:
        cor_detectada = Color.GREEN
    
    # Cinza: reflexão média
    elif intensidade_reflexao > PRETO_MAX and intensidade_reflexao < AMARELO_MIN:
        cor_detectada = Color.GRAY
        
    print(f"Cor Detectada: {cor_detectada} (Hue: {hue}, Ref: {intensidade_reflexao}, Heading: {hub.imu.heading():.1f}°)")
    
    return cor_detectada


# ==================== ESTAÇÃO DE TREM I ====================

def empurrar_azul_TI():
    """Empurra carrinho azul na estação I."""
    andar(44.5)      # Empurra azul (mais distante)
    wait(500)
    andar(-54)     # Volta
    volta_esquerda()


def empurrar_amarelo_TI():
    """Empurra carrinho amarelo na estação I."""
    andar(25.5)
    wait(500)      # Empurra amarelo
    andar(-36)     # Volta
    volta_esquerda()


def empurrar_cinza_TI():
    """Empurra carrinho cinza na estação I."""
    andar(13.5)
    wait(500)      # Empurra cinza (mais próximo)
    andar(-22)     # Volta
    volta_esquerda()


def empurrar_verde_TI():
    """Empurra carrinho verde na estação I."""
    andar(32.5) # Empurra verde
    wait(500)      
    andar(-43)     # Volta
    volta_esquerda()


# ==================== ESTAÇÃO DE TREM II ====================

def empurrar_azul_TII():
    """Empurra carrinho azul na estação II e leva para boxG."""
    andar(41.5)      # Empurra azul
    wait(500)
    andar(-52)     # Volta
    volta_direita()


def empurrar_amarelo_TII():
    """Empurra carrinho amarelo na estação II e leva para boxG."""
    andar(25.5)      # Empurra amarelo
    wait(300)
    andar(-25)     # Volta
    wait(200)
    volta_direita()
    boxG_amarelo()  # Leva para a posição correta


def empurrar_cinza_TII():
    """Empurra carrinho cinza na estação II e leva para boxG."""
    andar(11.5)      # Empurra cinza
    wait(100)
    andar(-22)     # Volta
    wait(100)
    volta_direita()
    boxG_cinza()   # Leva para a posição correta


def empurrar_verde_TII():
    """Empurra carrinho verde na estação II e leva para boxG."""
    andar(25.3)      # Empurra verde
    andar(-35.8)     # Volta
    volta_direita()
    boxG_verde()   # Leva para a posição correta


# ==================== ESTAÇÃO DE TREM III ====================

def empurrar_azul_TIII():
    """Empurra carrinho azul na estação III."""
    andar(42.5)    # Empurra azul
    wait(500)
    andar(-44.5)   # Volta
    volta_direita()


def empurrar_amarelo_TIII():
    """Empurra carrinho amarelo na estação III."""
    andar(25)      # Empurra amarelo
    andar(-27)     # Volta
    volta_direita()


def empurrar_cinza_TIII():
    """Empurra carrinho cinza na estação III."""
    andar(15)      # Empurra cinza
    andar(-17)     # Volta
    volta_direita()


def empurrar_verde_TIII():
    """Empurra carrinho verde na estação III."""
    andar(35)      # Empurra verde
    andar(-37)     # Volta
    volta_direita()


# ==================== ESTAÇÃO DE TREM IV ====================

def empurrar_azul_TIV():
    """Empurra carrinho azul na estação IV e executa route_VI."""
    andar(45)      # Empurra azul
    wait(500)
    andar(-47)     # Volta
    volta_direita()
    wait(200)
    route_VI_azul()  # Continua a rota específica


def empurrar_amarelo_TIV():
    """Empurra carrinho amarelo na estação IV e executa route_VI."""
    andar(25)      # Empurra amarelo
    andar(-27)     # Volta
    volta_direita()
    wait(200)
    route_VI_amarelo()


def empurrar_cinza_TIV():
    """Empurra carrinho cinza na estação IV e executa route_VI."""
    andar(15)      # Empurra cinza
    andar(-17)     # Volta
    volta_direita()
    wait(200)
    route_VI_cinza()


def empurrar_verde_TIV():
    """Empurra carrinho verde na estação IV e executa route_VI."""
    andar(35)      # Empurra verde
    andar(-37)     # Volta
    volta_direita()
    wait(200)
    route_VI_verde()


# ==================== MAPAS DE AÇÃO POR ESTAÇÃO ====================

map_train_I = {
    Color.BLUE: empurrar_azul_TI,
    Color.YELLOW: empurrar_amarelo_TI, 
    Color.GRAY: empurrar_cinza_TI,
    Color.GREEN: empurrar_verde_TI,
}

map_train_II = {
    Color.BLUE: empurrar_azul_TII,
    Color.YELLOW: empurrar_amarelo_TII,
    Color.GRAY: empurrar_cinza_TII,
    Color.GREEN: empurrar_verde_TII,
}

map_train_III = {
    Color.BLUE: empurrar_azul_TIII,
    Color.YELLOW: empurrar_amarelo_TIII,
    Color.GRAY: empurrar_cinza_TIII,
    Color.GREEN: empurrar_verde_TIII,
}

map_train_IV = {
    Color.BLUE: empurrar_azul_TIV,
    Color.YELLOW: empurrar_amarelo_TIV,
    Color.GRAY: empurrar_cinza_TIV,
    Color.GREEN: empurrar_verde_TIV,
}


# ==================== FUNÇÕES DE DETECÇÃO ====================

def _detectar_e_executar(sensor, mapa_acoes):
    """
    Função auxiliar para detectar cor e executar ação correspondente.
    
    Args:
        sensor: ColorSensor a ser usado (cs_dir ou cs_esq)
        mapa_acoes: Dicionário mapeando cores para funções de ação
    """
    wait(10)
    # Aguarda até detectar alguma cor
    while cs_dir.color() == Color.NONE and cs_esq.color() == Color.NONE:
        andar(0.5)
        wait(10)
    
    # Detecta cor usando HUE
    cor_detectada = get_cor_confiavel(sensor)
    
    # Executa ação correspondente à cor
    if cor_detectada in mapa_acoes:
        mapa_acoes[cor_detectada]()


def Trem1():
    """
    Detecta a cor do carrinho na estação I usando sensor esquerdo
    e empurra para a posição correta.
    """
    _detectar_e_executar(cs_esq, map_train_I)


def Trem2():
    """
    Detecta a cor do carrinho na estação II usando sensor direito
    e empurra para a posição correta, depois leva para boxG.
    """
    _detectar_e_executar(cs_dir, map_train_II)


def Trem3():
    """
    Detecta a cor do carrinho na estação III usando sensor direito
    e empurra para a posição correta.
    """
    _detectar_e_executar(cs_dir, map_train_III)


def Trem4():
    """
    Detecta a cor do carrinho na estação IV usando sensor direito
    e empurra para a posição correta, depois executa route_VI.
    """
    _detectar_e_executar(cs_dir, map_train_IV)

