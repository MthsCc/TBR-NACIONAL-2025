from pybricks.hubs import PrimeHub
from pybricks.parameters import Axis
from pybricks.tools import wait
from Drive_Train import andar, rotate
from consts import close, Open, cancela_direita, cancela_esquerda, volta_esquerda, volta_direita
from Trains import Trem2

hub = PrimeHub(top_side=Axis.X, front_side=Axis.Z)

#caixa verde com 2 carrinho
def Gbox():
    close()
    wait(100)
    andar(-15.5)
    hub.imu.reset_heading(0)
    rotate(45)
    cancela_esquerda()
    andar(-9.5)
    rotate(45)
    volta_esquerda()
    wait(300)
    andar(-1)
    cancela_direita()
    andar(2)
    Trem2()


def Bbox():
    close()
    andar(-40)
    rotate(-90)
    andar(25)
    rotate(90)
    andar(5)
    Open()
    andar(10)
    rotate(90)

