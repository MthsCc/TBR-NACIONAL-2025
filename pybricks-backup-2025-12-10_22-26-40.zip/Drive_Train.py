from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop, Axis
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub(top_side=Axis.X, front_side=Axis.Z)
claw = Motor(Port.A, Direction.CLOCKWISE)
claw.brake()
me = Motor(Port.F, Direction.COUNTERCLOCKWISE)
md = Motor(Port.C)
cancela = Motor(Port.B)
cs_dir = ColorSensor(Port.D)
cs_esq = ColorSensor(Port.E)

drive_base = DriveBase(me, md, 54, 115) 
drive_base.use_gyro(True)

def _bt_pressionado() -> bool:
    return Button.BLUETOOTH in hub.buttons.pressed()


def esperar_bt_press_release(msg: str | None = None):
    if msg:
        print(msg)
    while not _bt_pressionado():
        wait(50)
    while _bt_pressionado():
        wait(50)


def aguardar_calibrar_imu():
    """
    Clique 1 (Bluetooth): calibra IMU, sinaliza laranja->verde.
    Clique 2 (Bluetooth): inicia missão, LED azul.
    """
    esperar_bt_press_release("Pressione Bluetooth para calibrar IMU")
    hub.light.on(Color.ORANGE)
    print("Calibrando IMU...")
    while not hub.imu.ready():
        wait(50)
    hub.imu.reset_heading(0)
    hub.light.on(Color.GREEN)
    print("IMU calibrada. Pressione Bluetooth para iniciar")
    esperar_bt_press_release()
    hub.light.on(Color.BLUE)
    print("Iniciando missão...")


def parar_se_bluetooth() -> bool:
    """Detecta pedido de parada via botão Bluetooth."""
    if _bt_pressionado():
        print("Parada solicitada pelo botão Bluetooth.")
        hub.light.on(Color.RED)
        return True
    return False

def _wrap_angle(error: float) -> float:
    """Normaliza erro de heading para o intervalo [-180, 180]."""
    while error > 180:
        error -= 360
    while error < -180:
        error += 360
    return error


def andar(dist, velocidade=350, kp=3, ki=0, kd=1.2, limite_giro=120):
    alvo_mm = dist * 10
    direcao = 1 if alvo_mm >= 0 else -1
    velocidade_base = abs(velocidade)

    # aceleração e desaceleração máximas
    drive_base.settings(
        straight_speed=500,
        straight_acceleration=300,
        turn_rate=220,
        turn_acceleration=220
    )

    drive_base.reset()
    heading_alvo = hub.imu.heading()

    integral = 0.0
    erro_anterior = 0.0

    while direcao * drive_base.distance() < direcao * alvo_mm:

        # >>> DESACELERAÇÃO PROGRESSIVA <<<
        dist_perc = abs(alvo_mm - drive_base.distance()) / abs(alvo_mm)
        dist_perc = max(min(dist_perc, 1), 0)   # clamp 0–1

        # entra mais lento na parte final
        vel = velocidade_base * (0.3 + 0.7 * dist_perc)
        vel *= direcao

        # PID de heading
        erro = _wrap_angle(heading_alvo - hub.imu.heading())
        integral = max(min(integral + erro, 500), -500)
        deriv = erro - erro_anterior

        correcao = kp * erro + ki * integral + kd * deriv
        correcao = max(min(correcao, limite_giro), -limite_giro)

        drive_base.drive(vel, correcao)

        erro_anterior = erro
        wait(10)

    drive_base.brake()

def descida(dist, velocidade=150, kp=3.0, ki=0.03, kd=0.8, limite_giro=120):
    alvo_mm = dist * 10
    direcao = 1 if alvo_mm >= 0 else -1
    velocidade = abs(velocidade) * direcao

    drive_base.settings(350, 350, 220, 220)
    drive_base.reset()

    heading_alvo = hub.imu.heading()
    integral = 0.0
    erro_anterior = 0.0

    distancia_total = abs(alvo_mm)
    zona_rampa = 100  # últimos 200mm = 20cm desacelerando

    while direcao * drive_base.distance() < direcao * alvo_mm:
        erro = _wrap_angle(heading_alvo - hub.imu.heading())
        integral = max(min(integral + erro, 500), -500)
        deriv = erro - erro_anterior

        correcao = kp * erro + ki * integral + kd * deriv
        correcao = max(min(correcao, limite_giro), -limite_giro)

        # --- desaceleração baseada na distância ---
        distancia_percorrida = abs(drive_base.distance())
        restante = distancia_total - distancia_percorrida

        if restante < zona_rampa:
            fator = restante / zona_rampa
            fator = max(0.25, fator)
        else:
            fator = 1.0

        velocidade_atual = velocidade * fator
        # ------------------------------------------

        drive_base.drive(velocidade_atual, correcao)

        erro_anterior = erro
        wait(10)

    drive_base.brake()

def turn(radius, angle):
    drive_base.settings(200, 200, 200, 200)
    drive_base.curve(radius, angle)

def estabilizar_imu(tempo_espera=200, tolerancia=0.5, max_tentativas=20):
    """
    Aguarda a IMU se estabilizar após movimentos de motores.
    Útil após operações de garra, cancela, etc.
    """
    wait(tempo_espera)  # aguarda vibrações iniciais cessarem
    
    heading_inicial = hub.imu.heading()
    tentativas = 0
    
    while tentativas < max_tentativas:
        wait(50)
        heading_atual = hub.imu.heading()
        variacao = abs(_wrap_angle(heading_atual - heading_inicial))
        
        if variacao <= tolerancia:
            # IMU estável, mantém o heading atual como referência
            return
        
        heading_inicial = heading_atual
        tentativas += 1
    
    # Se não estabilizou completamente, pelo menos aguardou o tempo mínimo
    print(f"IMU: estabilização parcial após {max_tentativas} tentativas")


def rotate(graus, velocidade=None):
    """
    Giro com controle PID usando IMU para maior precisão.
    Otimizado para giros à esquerda (negativos) e direita (positivos).
    graus: alvo relativo ao heading atual.
    velocidade: parâmetro opcional para compatibilidade (ignorado).
    """
    # Ajustes diferentes para esquerda (negativo) e direita (positivo)
    if graus < 0:  # Giro à esquerda - mais preciso
        kp, ki, kd = 3.35, 0, 1.1
        limite_giro = 300
        tolerancia = 0.6
    else:  # Giro à direita
        kp, ki, kd = 3.35, 0, 1.1
        limite_giro = 320
        tolerancia = 0.8

    heading_atual = hub.imu.heading()
    alvo = heading_atual + graus
    
    # Normaliza alvo para [-180, 180]
    while alvo > 180:
        alvo -= 360
    while alvo < -180:
        alvo += 360

    integral = 0.0
    erro_anterior = 0.0
    contador_estavel = 0
    max_estavel = 3  # precisa estar estável por 3 iterações

    drive_base.stop()
    wait(50)  # pequena pausa para garantir que parou

    while True:
        heading_atual = hub.imu.heading()
        erro = _wrap_angle(alvo - heading_atual)
        
        # Verifica se está dentro da tolerância
        if abs(erro) <= tolerancia:
            contador_estavel += 1
            if contador_estavel >= max_estavel:
                break
        else:
            contador_estavel = 0

        # Calcula PID
        integral = max(min(integral + erro, 500), -500)
        deriv = erro - erro_anterior

        correcao = kp * erro + ki * integral + kd * deriv
        correcao = max(min(correcao, limite_giro), -limite_giro)

        drive_base.drive(0, correcao)

        erro_anterior = erro
        wait(10)

    drive_base.stop()
    wait(100)  # aguarda estabilização final
    
    # Correção final se necessário (overshoot pequeno)
    heading_final = hub.imu.heading()
    erro_final = _wrap_angle(alvo - heading_final)
    if abs(erro_final) > tolerancia * 1.5:  # se ainda estiver muito fora
        drive_base.turn(erro_final)
        wait(50)
    
    drive_base.brake()



def testar_giro(graus, kp, ki, kd, limite_giro=300, tolerancia=0.6):
    """
    Testa um giro com parâmetros PID específicos e retorna métricas de precisão.
    Retorna: (erro_final, tempo_ms, overshoot_max)
    """
    drive_base.brake()
    wait(200)  # aguarda estabilização inicial
    
    # RESETA o heading da IMU para 0 para evitar acúmulo
    # (reset_heading só aceita 0 em Pybricks)
    hub.imu.reset_heading(0)
    wait(100)
    
    # Configura drive_base para giros (valores mínimos para evitar erro)
    drive_base.settings(straight_speed=50, straight_acceleration=50, turn_rate=limite_giro, turn_acceleration=limite_giro)
    
    heading_inicial = hub.imu.heading()
    alvo = heading_inicial + graus
    
    # Normaliza alvo para [-180, 180]
    alvo = _wrap_angle(alvo)
    
    # Debug: mostra valores iniciais
    erro_inicial = _wrap_angle(alvo - heading_inicial)
    print(f"Giro: {graus}° | Heading inicial: {heading_inicial:.1f}° | Alvo: {alvo:.1f}° | Erro inicial: {erro_inicial:.1f}°")
    
    integral = 0.0
    erro_anterior = erro_inicial
    contador_estavel = 0
    max_estavel = 3
    overshoot_max = abs(erro_inicial)
    max_iteracoes = 2000  # timeout reduzido: ~20 segundos máximo
    iteracao = 0
    erro_anterior_abs = abs(erro_inicial)
    contador_sem_melhoria = 0
    
    timer = StopWatch()
    
    while iteracao < max_iteracoes:
        heading_atual = hub.imu.heading()
        erro = _wrap_angle(alvo - heading_atual)
        erro_abs = abs(erro)
        
        # Registra overshoot máximo (só se for maior que o inicial)
        if erro_abs > overshoot_max:
            overshoot_max = erro_abs
        
        # Verifica se está melhorando
        if erro_abs < erro_anterior_abs:
            contador_sem_melhoria = 0
        else:
            contador_sem_melhoria += 1
        
        # Se não está melhorando há muito tempo E o erro é muito grande, para
        if iteracao > 500 and contador_sem_melhoria > 200 and erro_abs > 45:
            print(f"AVISO: Giro não está melhorando. Erro: {erro_abs:.2f}° após {iteracao} iterações")
            break
        
        if erro_abs <= tolerancia:
            contador_estavel += 1
            if contador_estavel >= max_estavel:
                break
        else:
            contador_estavel = 0
        
        # Se o erro não está diminuindo e já tentou muito, força parada
        if iteracao > 2000 and erro_abs > tolerancia * 5:
            print(f"AVISO: Giro travado após {iteracao} iterações. Parando com erro: {erro_abs:.2f}°")
            break
        
        integral = max(min(integral + erro, 500), -500)
        deriv = erro - erro_anterior
        
        correcao = kp * erro + ki * integral + kd * deriv
        correcao = max(min(correcao, limite_giro), -limite_giro)
        
        # Usa drive_base.drive com velocidade 0 e correção angular
        # Garante velocidade mínima para movimento
        if abs(correcao) < 20:
            correcao = 20 if correcao >= 0 else -20
        
        drive_base.drive(0, correcao)
        erro_anterior = erro
        erro_anterior_abs = erro_abs
        iteracao += 1
        wait(10)
    
    # Para o robô - sem argumentos para evitar erro
    drive_base.brake()
    wait(100)
    
    heading_final = hub.imu.heading()
    erro_final = _wrap_angle(alvo - heading_final)
    tempo_ms = timer.time()
    
    if iteracao >= max_iteracoes:
        print(f"AVISO: Timeout atingido após {max_iteracoes} iterações. Erro final: {abs(erro_final):.2f}°")
    
    return abs(erro_final), tempo_ms, abs(overshoot_max)


def calibrar_giro_esquerda():
    """
    Calibra os valores PID para giros à esquerda.
    Testa diferentes combinações e mostra os resultados.
    """
    print("=== CALIBRAÇÃO GIRO ESQUERDA ===")
    print("Testando diferentes valores de PID...")
    
    aguardar_calibrar_imu()
    
    # Valores para testar
    kp_values = [4.0, 4.5, 5.0, 5.5, 6.0]
    ki_values = [0.03, 0.04, 0.05, 0.06, 0.07]
    kd_values = [1.2, 1.3, 1.4, 1.5, 1.6]
    
    melhor_erro = 999.0
    melhor_config = None
    
    print("\nTestando combinações (pode demorar)...")
    print("KP | KI | KD | Erro Final | Tempo | Overshoot")
    print("-" * 50)
    
    for kp in kp_values:
        for ki in ki_values:
            for kd in kd_values:
                # Testa giro de -90 graus
                erro, tempo, overshoot = testar_giro(-90, kp, ki, kd)
                
                print(f"{kp:.1f} | {ki:.2f} | {kd:.1f} | {erro:.2f}° | {tempo}ms | {overshoot:.2f}°")
                
                # Score: menor erro é melhor, mas penaliza overshoot e tempo
                score = erro + (overshoot * 0.5) + (tempo / 1000)
                
                if score < melhor_erro:
                    melhor_erro = score
                    melhor_config = {"kp": kp, "ki": ki, "kd": kd, "erro": erro, "tempo": tempo, "overshoot": overshoot}
                
                wait(500)  # pausa entre testes
    
    print("\n" + "=" * 50)
    print("MELHOR CONFIGURAÇÃO ENCONTRADA:")
    print(f"KP = {melhor_config['kp']:.2f}")
    print(f"KI = {melhor_config['ki']:.3f}")
    print(f"KD = {melhor_config['kd']:.2f}")
    print(f"Erro final: {melhor_config['erro']:.2f}°")
    print(f"Tempo: {melhor_config['tempo']}ms")
    print(f"Overshoot: {melhor_config['overshoot']:.2f}°")
    print("\nAtualize os valores no código com esses valores!")


def calibrar_giro_direita():
    """
    Calibra os valores PID para giros à direita.
    """
    print("=== CALIBRAÇÃO GIRO DIREITA ===")
    print("Testando diferentes valores de PID...")
    
    aguardar_calibrar_imu()
    
    kp_values = [3.5, 4.0, 4.5, 5.0]
    ki_values = [0.03, 0.04, 0.05, 0.06]
    kd_values = [1.0, 1.1, 1.2, 1.3]
    
    melhor_erro = 999.0
    melhor_config = None
    
    print("\nTestando combinações...")
    print("KP | KI | KD | Erro Final | Tempo | Overshoot")
    print("-" * 50)
    
    for kp in kp_values:
        for ki in ki_values:
            for kd in kd_values:
                erro, tempo, overshoot = testar_giro(90, kp, ki, kd)
                
                print(f"{kp:.1f} | {ki:.2f} | {kd:.1f} | {erro:.2f}° | {tempo}ms | {overshoot:.2f}°")
                
                score = erro + (overshoot * 0.5) + (tempo / 1000)
                
                if score < melhor_erro:
                    melhor_erro = score
                    melhor_config = {"kp": kp, "ki": ki, "kd": kd, "erro": erro, "tempo": tempo, "overshoot": overshoot}
                
                wait(500)
    
    print("\n" + "=" * 50)
    print("MELHOR CONFIGURAÇÃO ENCONTRADA:")
    print(f"KP = {melhor_config['kp']:.2f}")
    print(f"KI = {melhor_config['ki']:.3f}")
    print(f"KD = {melhor_config['kd']:.2f}")
    print(f"Erro final: {melhor_config['erro']:.2f}°")
    print(f"Tempo: {melhor_config['tempo']}ms")
    print(f"Overshoot: {melhor_config['overshoot']:.2f}°")
    print("\nAtualize os valores no código com esses valores!")


def ajuste_manual_giro(graus=-90):
    """
    Permite ajuste manual interativo dos valores PID.
    Use os botões do hub para ajustar:
    - Botão Esquerda: diminui KP
    - Botão Direita: aumenta KP
    - Botão Centro: testa e mostra resultado
    - Botão Bluetooth: salva e termina
    """
    print("=== AJUSTE MANUAL PID ===")
    print("Esquerda: -KP | Direita: +KP | Centro: Testa | Bluetooth: Salva")
    
    kp = 5.0
    ki = 0.05
    kd = 1.5
    
    while True:
        print(f"\nKP={kp:.2f} KI={ki:.3f} KD={kd:.2f}")
        print("Ajuste KP com Esquerda/Direita, teste com Centro, salve com Bluetooth")
        
        while True:
            botoes = hub.buttons.pressed()
            if Button.LEFT in botoes:
                kp = max(1.0, kp - 0.1)
                wait(200)
                break
            elif Button.RIGHT in botoes:
                kp = min(10.0, kp + 0.1)
                wait(200)
                break
            elif Button.CENTER in botoes:
                print(f"\nTestando giro de {graus}°...")
                erro, tempo, overshoot = testar_giro(graus, kp, ki, kd)
                print(f"Resultado: Erro={erro:.2f}° | Tempo={tempo}ms | Overshoot={overshoot:.2f}°")
                wait(500)
                break
            elif Button.BLUETOOTH in botoes:
                print(f"\nValores finais salvos:")
                print(f"KP={kp:.2f}, KI={ki:.3f}, KD={kd:.2f}")
                return {"kp": kp, "ki": ki, "kd": kd}
            wait(50)

def rodar(graus):
    drive_base.settings(220, 220, 220, 220)
    drive_base.turn(graus)
    drive_base.brake()