# SCRIPT DE TESTE DE TONALIDADE (NAO DEVE SER USADO NA MISSAO PRINCIPAL)
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import ColorSensor
from pybricks.parameters import Port
from pybricks.tools import wait

hub = PrimeHub()
cs_dir = ColorSensor(Port.E) # Use o sensor que está dando problema

#312-320, reflexao 36, color white
#225-226, reflexao 27, color blue
#149, reflexao 35, color green

print("--- TESTE DE TONALIDADE (HUE) ---")
print("Coloque o sensor sobre as cores e anote o primeiro número (HUE).")

while True:
    # O sensor.hsv() retorna (Hue, Saturation, Value)
    hsv = cs_dir.hsv()
    cor_pybricks = cs_dir.color()
    print(f"HUE: {hsv[0]} | REFLEXÃO: {cs_dir.reflection()} | COR: {cor_pybricks}")
    wait(500)