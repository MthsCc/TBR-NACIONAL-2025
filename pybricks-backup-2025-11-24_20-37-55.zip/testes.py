from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from Drive_Train import andar, rotate, turn
from consts import Open, close, upper, low, mid, deposit, cancela_esquerda, cancela_direita, volta_direita, volta_esquerda, direita_direto, esquerda_direto
from functions import detect_train_I, detect_train_II, detect_train_III, detect_train_IV
from Rota_1 import route_VI_amarelo, route_VI_azul, route_VI_cinza, route_VI_verde, 
from Rota_1 import route_V, park


hub = PrimeHub()
#Verde
# andar(34)
# andar(-36)

#Amarelo
# andar(23.5)
# andar(-25.5)

# cinza
# andar(14.2)
# andar(-16.2)

# azul
# andar(46)
# andar(-48)
while True:
    battery_voltage = hub.battery.voltage()
    print("Nivel da bateria", battery_voltage / 1000, "V")
    wait(1000) 
