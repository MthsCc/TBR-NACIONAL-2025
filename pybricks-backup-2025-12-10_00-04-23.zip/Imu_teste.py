from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.robotics import DriveBase
from pybricks.parameters import Port, Axis, Direction
from pybricks.tools import wait
from Drive_Train import rotate, andar, aguardar_calibrar_imu, parar_se_bluetooth, parar_se_bluetooth
from consts import close, cancela_esquerda, cancela_direita, Open
from Trains import detectar_e_empurrar_TI


hub = PrimeHub(top_side=Axis.X, front_side=Axis.Z)

aguardar_calibrar_imu()  # clique 1 calibra IMU (laranja->verde), clique 2 inicia (azul)
#andar(10)
cancela_esquerda()
detectar_e_empurrar_TI()
#andar(-13)
#rotate(90)
#andar(30)
#rotate(90)
#rotate(-90)
#rotate(-180)
#andar(25)
#wait(200)
#rotate(-90)
#wait(200)
#andar(35)
#rotate(-90)
#andar(22)
#rotate(90)
#cancela_esquerda()
#carrinho
#cancela_direita()
#rotate(90)
#andar(55)
#rotate(90)
#andar(10)
#close()
#andar(-15)
#rotate(90)
#andar(-5)
#cancela_direita()
#carrinho
#cancela_esquerda()
#andar(35)
#rotate(-90)
#andar(74)
#rotate(90)
#andar(24)
#Open()
#andar(-24)
#rotate(-90)
#andar(75)
#rotate(90)
#andar(25)
#rotate(-90)
#andar(5)
#cancela_direita()
#carrinho
#cancela_esquerda()
#andar(20)


