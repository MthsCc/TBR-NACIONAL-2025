from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from Drive_Train import claw, andar, turn, rotate, cancela, estabilizar_imu

hub = PrimeHub()

def Open():
    claw.run_target(2000, -20)
    estabilizar_imu()

def close():
    claw.run_target(2000, 250)
    estabilizar_imu()

def low():
    claw.run_target(2000, 320)
    estabilizar_imu()

def mid():
    claw.run_target(2000, 380)
    estabilizar_imu()

def upper():
    claw.run_target(2000, 560)
    estabilizar_imu()

def deposit():
    claw.run_target(1800, 770)
    estabilizar_imu()

def cancela_esquerda():
    cancela.run_angle(1800, 170)
    estabilizar_imu()

def volta_esquerda():
    cancela.run_angle(1800, -105)
    estabilizar_imu()

def cancela_direita():
    cancela.run_angle(1800, -180)
    estabilizar_imu()

def volta_direita():
    cancela.run_angle(1800, 150)
    estabilizar_imu()

def direita_direto():
    cancela.run_angle(1950, 150)
    estabilizar_imu()

def esquerda_direto():
    cancela.run_angle(1950, -250)
    estabilizar_imu()