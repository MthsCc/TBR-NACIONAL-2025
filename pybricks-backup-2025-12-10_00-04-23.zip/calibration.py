# SCRIPT DE TESTE DE TONALIDADE (NAO DEVE SER USADO NA MISSAO PRINCIPAL)
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import ColorSensor
from pybricks.parameters import Port
from pybricks.tools import wait
"""
Script de calibração PID para encontrar os valores perfeitos.
Execute este arquivo para calibrar os valores de PID do seu robô.
"""

"""
Script de calibração PID para encontrar os valores perfeitos.
Execute este arquivo para calibrar os valores de PID do seu robô.
"""

from Drive_Train import (
    calibrar_giro_esquerda,
    calibrar_giro_direita,
    ajuste_manual_giro,
    aguardar_calibrar_imu,
    hub,
    Button,
    wait,
    Color
)

def menu_calibracao():
    """Menu interativo para escolher o tipo de calibração."""
    print("\n" + "=" * 50)
    print("CALIBRAÇÃO PID - SPIKE PRIME")
    print("=" * 50)
    print("\nEscolha o tipo de calibração:")
    print("1. Calibração automática - Giro Esquerda")
    print("2. Ajuste manual interativo")
    print("3. Calibração automática - Giro Direita")
    print("\nUse os botões do hub:")
    print("  Esquerda = Opção 1")
    print("  Centro = Opção 2 (Ajuste Manual)")
    print("  Direita = Opção 3")
    print("  Bluetooth = Sair")
    
    while True:
        botoes = hub.buttons.pressed()
        if Button.LEFT in botoes:
            hub.light.on(Color.GREEN)
            wait(500)
            calibrar_giro_esquerda()
            break
        elif Button.CENTER in botoes:
            hub.light.on(Color.ORANGE)
            wait(500)
            print("\n=== AJUSTE MANUAL ===")
            print("Escolha o tipo de giro para testar:")
            print("Esquerda = -90° | Centro = 90° | Direita = 180°")
            while True:
                b = hub.buttons.pressed()
                if Button.LEFT in b:
                    ajuste_manual_giro(-90)
                    break
                elif Button.CENTER in b:
                    ajuste_manual_giro(90)
                    break
                elif Button.RIGHT in b:
                    ajuste_manual_giro(180)
                    break
                wait(50)
            break
        elif Button.RIGHT in botoes:
            hub.light.on(Color.YELLOW)
            wait(500)
            calibrar_giro_direita()
            break
        elif Button.BLUETOOTH in botoes:
            hub.light.on(Color.RED)
            print("Saindo...")
            return
        wait(50)

if __name__ == "__main__":
    aguardar_calibrar_imu()
    menu_calibracao()



hub = PrimeHub()
cs_dir = ColorSensor(Port.E) # Use o sensor que está dando problema

#312-320, reflexao 36, color white
#225-226, reflexao 27, color blue
#149, reflexao 35, color green

print("--- TESTE DE TONALIDADE (HUE) ---")
print("Coloque o sensor sobre as cores e anote o primeiro número (HUE).")

while True:
    # O sensor.hsv() retorna (Hue, Saturation, Value)
    hsv = cs_dir.hsv()
    cor_pybricks = cs_dir.color()
    print(f"HUE: {hsv[0]} | REFLEXÃO: {cs_dir.reflection()} | COR: {cor_pybricks}")
    wait(500)
calibrar_giro_direita()
calibrar_giro_esquerda() 