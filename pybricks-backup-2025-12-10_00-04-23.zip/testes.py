from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.robotics import DriveBase
from pybricks.parameters import Port, Direction, Axis, Color, Button
from pybricks.tools import wait

# --- CONFIGURAÇÃO DA HUB E EIXOS (Ajustar conforme a orientação física) ---
# Se o hub estiver montado verticalmente (lado USB para cima/baixo), use o de baixo.
# Se o hub estiver montado horizontalmente (botão para cima), use o de cima.
hub = PrimeHub()
# hub = PrimeHub() # Opção para hub horizontal

# --- CONSTANTES DE HARDWARE ---
DIAMETRO_RODA = 56
DISTANCIA_EIXOS = 114

# --- CONFIGURAÇÃO DO ROBÔ ---
motor_esq = Motor(Port.F, Direction.COUNTERCLOCKWISE)
motor_dir = Motor(Port.C)
robot = DriveBase(motor_esq, motor_dir, DIAMETRO_RODA, DISTANCIA_EIXOS)

# --- VARIÁVEIS DE CONTROLE ---
VELOCIDADE_PADRAO = 150 
ANGULO_ALVO = 0         
LOOP_TEMPO_MS = 10      

# --- VARIÁVEIS PID (PD Controller) ---
# Ganhos AGRESSIVOS para forçar a correção.
GANHO_P = 1
GANHO_D = 0

ERRO_ANTERIOR = 0

# --- FUNÇÃO DE DIFERENÇA ANGULAR ---

def angle_diff(target, current):
    """Calcula a menor diferença angular (erro) no range [-180, 180)."""
    d = (target - current + 180) % 360 - 180
    return d

# --- ROTINA DE CALIBRAÇÃO E INÍCIO ---

def calibrar_e_aguardar_inicio():
    """Inicializa, aguarda e espera pelo botão LEFT."""
    
    hub.display.text("CAL")
    hub.light.on(Color.RED)
    print("Aguardando inicialização da IMU (2s)...")
    wait(2000) 
    
    hub.light.on(Color.BLUE) 
    hub.display.text("LEFT")
    print("Pronto. Pressione SETA ESQUERDA para iniciar o controle.")
    
    while Button.LEFT not in hub.buttons.pressed():
        wait(10)

    # Reset (Calibração)
    hub.imu.reset_heading(ANGULO_ALVO) 
    motor_esq.reset_angle(0)
    motor_dir.reset_angle(0)
    
    hub.light.on(Color.GREEN)
    hub.display.text("RUN")
    print("--- INÍCIO: ESTABILIZAÇÃO ATIVA ---")

# --- PROGRAMA PRINCIPAL ---

# 1. Executa a rotina de inicialização
calibrar_e_aguardar_inicio()

while True:
    
    # 🚨 Parada de Emergência
    if Button.RIGHT in hub.buttons.pressed() or Button.CENTER in hub.buttons.pressed():
        robot.stop()
        hub.light.on(Color.RED)
        hub.display.text("END")
        break
    
    # --- 1. Leitura e Cálculo do Erro ---
    angulo_atual = hub.imu.heading() 
    erro_angular = angle_diff(ANGULO_ALVO, angulo_atual)
    
    # 2. Componentes PD
    erro_derivativo = erro_angular - ERRO_ANTERIOR
    
    componente_p = erro_angular * GANHO_P
    componente_d = erro_derivativo * GANHO_D
    
    correcao_de_giro = componente_p + componente_d
    
    # Atualiza o erro
    erro_anterior = erro_angular 
    
    # --- 3. Comando de Atuação (TESTE DE SINAL AQUI) ---
    
    # **A LINHA CRÍTICA:** Se o robô girar mais ao invés de corrigir,
    # REMOVA o sinal negativo e use 'correcao_de_giro'.
    robot.drive(VELOCIDADE_PADRAO, -correcao_de_giro) 
    
    # --- 4. Feedback Visual ---
    # Mostra o erro de ângulo no display do hub para diagnóstico
    hub.display.text(f"E:{erro_angular:.1f}")

    wait(LOOP_TEMPO_MS)

# --- FINALIZAÇÃO ---
hub.light.off()