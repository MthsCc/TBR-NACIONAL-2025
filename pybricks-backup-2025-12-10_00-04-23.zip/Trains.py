"""
Funções para detectar e empurrar carrinhos baseado na cor detectada via HUE.
Cada cor (Azul, Amarelo, Verde, Cinza) tem uma função específica para cada estação de trem.
"""

from pybricks.pupdevices import ColorSensor
from pybricks.parameters import Color
from pybricks.tools import wait

from Drive_Train import andar, cs_dir, cs_esq, hub
from consts import deposit, volta_direita, volta_esquerda
from Rota_1 import boxG_amarelo, boxG_azul, boxG_cinza, boxG_verde
from Rota_1 import route_VI_amarelo, route_VI_azul, route_VI_cinza, route_VI_verde

# Constantes para detecção de cor via HUE
PRETO_MAX = 15
AMARELO_MIN = 60
HUE_SATURACAO_MIN = 20

HUE_AZUL_MIN = 200
HUE_AZUL_MAX = 240 
HUE_VERDE_MIN = 120
HUE_VERDE_MAX = 180 


def get_cor_confiavel(sensor: ColorSensor) -> Color:
    """
    Detecta a cor do carrinho usando HUE e reflexão.
    Retorna: Color (BLUE, YELLOW, GREEN, GRAY, BLACK, NONE)
    """
    intensidade_reflexao = sensor.reflection()
    hsv = sensor.hsv()  # (Hue, Saturation, Value)
    hue = hsv[0]
    saturation = hsv[1]
    
    cor_detectada = Color.NONE

    # Amarelo: alta reflexão + hue entre 40-70
    if intensidade_reflexao >= AMARELO_MIN:
        if hue > 40 and hue < 70 and saturation > HUE_SATURACAO_MIN:
            cor_detectada = Color.YELLOW
        else:
            cor_detectada = Color.GRAY
    
    # Preto: baixa reflexão
    elif intensidade_reflexao <= PRETO_MAX:
        cor_detectada = Color.BLACK

    # Azul: hue entre 200-240
    elif hue >= HUE_AZUL_MIN and hue <= HUE_AZUL_MAX and saturation > HUE_SATURACAO_MIN:
        cor_detectada = Color.BLUE
    
    # Verde: hue entre 120-180
    elif hue >= HUE_VERDE_MIN and hue <= HUE_VERDE_MAX and saturation > HUE_SATURACAO_MIN:
        cor_detectada = Color.GREEN
    
    # Cinza: reflexão média
    elif intensidade_reflexao > PRETO_MAX and intensidade_reflexao < AMARELO_MIN:
        cor_detectada = Color.GRAY
        
    print(f"Cor Detectada: {cor_detectada} (Hue: {hue}, Ref: {intensidade_reflexao}, Heading: {hub.imu.heading():.1f}°)")
    
    return cor_detectada


# ==================== ESTAÇÃO DE TREM I ====================

def empurrar_azul_TI():
    """Empurra carrinho azul na estação I."""
    deposit()
    andar(46)      # Empurra azul (mais distante)
    wait(500)
    andar(-50)     # Volta
    volta_esquerda()


def empurrar_amarelo_TI():
    """Empurra carrinho amarelo na estação I."""
    andar(25)      # Empurra amarelo
    andar(-29)     # Volta
    volta_esquerda()


def empurrar_cinza_TI():
    """Empurra carrinho cinza na estação I."""
    andar(15)      # Empurra cinza (mais próximo)
    andar(-19)     # Volta
    volta_esquerda()


def empurrar_verde_TI():
    """Empurra carrinho verde na estação I."""
    andar(35)      # Empurra verde
    andar(-39)     # Volta
    volta_esquerda()


# ==================== ESTAÇÃO DE TREM II ====================

def empurrar_azul_TII():
    """Empurra carrinho azul na estação II e leva para boxG."""
    andar(45)      # Empurra azul
    wait(500)
    andar(-47)     # Volta
    volta_direita()
    boxG_azul()    # Leva para a posição correta


def empurrar_amarelo_TII():
    """Empurra carrinho amarelo na estação II e leva para boxG."""
    andar(24)      # Empurra amarelo
    wait(300)
    andar(-26)     # Volta
    wait(200)
    volta_direita()
    boxG_amarelo()  # Leva para a posição correta


def empurrar_cinza_TII():
    """Empurra carrinho cinza na estação II e leva para boxG."""
    andar(13)      # Empurra cinza
    wait(100)
    andar(-15)     # Volta
    wait(100)
    volta_direita()
    boxG_cinza()   # Leva para a posição correta


def empurrar_verde_TII():
    """Empurra carrinho verde na estação II e leva para boxG."""
    andar(34)      # Empurra verde
    andar(-36)     # Volta
    volta_direita()
    boxG_verde()   # Leva para a posição correta


# ==================== ESTAÇÃO DE TREM III ====================

def empurrar_azul_TIII():
    """Empurra carrinho azul na estação III."""
    andar(42.5)    # Empurra azul
    wait(500)
    andar(-44.5)   # Volta
    volta_direita()


def empurrar_amarelo_TIII():
    """Empurra carrinho amarelo na estação III."""
    andar(25)      # Empurra amarelo
    andar(-27)     # Volta
    volta_direita()


def empurrar_cinza_TIII():
    """Empurra carrinho cinza na estação III."""
    andar(15)      # Empurra cinza
    andar(-17)     # Volta
    volta_direita()


def empurrar_verde_TIII():
    """Empurra carrinho verde na estação III."""
    andar(35)      # Empurra verde
    andar(-37)     # Volta
    volta_direita()


# ==================== ESTAÇÃO DE TREM IV ====================

def empurrar_azul_TIV():
    """Empurra carrinho azul na estação IV e executa route_VI."""
    andar(45)      # Empurra azul
    wait(500)
    andar(-47)     # Volta
    volta_direita()
    wait(200)
    route_VI_azul()  # Continua a rota específica


def empurrar_amarelo_TIV():
    """Empurra carrinho amarelo na estação IV e executa route_VI."""
    andar(25)      # Empurra amarelo
    andar(-27)     # Volta
    volta_direita()
    wait(200)
    route_VI_amarelo()  # Continua a rota específica


def empurrar_cinza_TIV():
    """Empurra carrinho cinza na estação IV e executa route_VI."""
    andar(15)      # Empurra cinza
    andar(-17)     # Volta
    volta_direita()
    wait(200)
    route_VI_cinza()  # Continua a rota específica


def empurrar_verde_TIV():
    """Empurra carrinho verde na estação IV e executa route_VI."""
    andar(35)      # Empurra verde
    andar(-37)     # Volta
    volta_direita()
    wait(200)
    route_VI_verde()  # Continua a rota específica


# ==================== MAPAS DE AÇÃO POR ESTAÇÃO ====================

map_train_I = {
    Color.BLUE: empurrar_azul_TI,
    Color.YELLOW: empurrar_amarelo_TI, 
    Color.GRAY: empurrar_cinza_TI,
    Color.GREEN: empurrar_verde_TI,
}

map_train_II = {
    Color.BLUE: empurrar_azul_TII,
    Color.YELLOW: empurrar_amarelo_TII,
    Color.GRAY: empurrar_cinza_TII,
    Color.GREEN: empurrar_verde_TII,
}

map_train_III = {
    Color.BLUE: empurrar_azul_TIII,
    Color.YELLOW: empurrar_amarelo_TIII,
    Color.GRAY: empurrar_cinza_TIII,
    Color.GREEN: empurrar_verde_TIII,
}

map_train_IV = {
    Color.BLUE: empurrar_azul_TIV,
    Color.YELLOW: empurrar_amarelo_TIV,
    Color.GRAY: empurrar_cinza_TIV,
    Color.GREEN: empurrar_verde_TIV,
}


# ==================== FUNÇÕES DE DETECÇÃO ====================

def detectar_e_empurrar_TI():
    """
    Detecta a cor do carrinho na estação I usando sensor esquerdo
    e empurra para a posição correta.
    """
    wait(10) 
    # Aguarda até detectar alguma cor
    while cs_dir.color() == Color.NONE and cs_esq.color() == Color.NONE:
        andar(0.5)
        wait(10)
    
    # Detecta cor usando HUE no sensor esquerdo
    cor_detectada = get_cor_confiavel(cs_esq)
    
    # Executa ação correspondente à cor
    if cor_detectada in map_train_I:
        map_train_I[cor_detectada]()


def detectar_e_empurrar_TII():
    """
    Detecta a cor do carrinho na estação II usando sensor direito
    e empurra para a posição correta, depois leva para boxG.
    """
    wait(10)
    # Aguarda até detectar alguma cor
    while cs_dir.color() == Color.NONE and cs_esq.color() == Color.NONE:
        andar(0.5)
        wait(10)
    
    # Detecta cor usando HUE no sensor direito
    cor_detectada = get_cor_confiavel(cs_dir)
    
    # Executa ação correspondente à cor
    if cor_detectada in map_train_II:
        map_train_II[cor_detectada]()


def detectar_e_empurrar_TIII():
    """
    Detecta a cor do carrinho na estação III usando sensor direito
    e empurra para a posição correta.
    """
    wait(10)
    # Aguarda até detectar alguma cor
    while cs_dir.color() == Color.NONE and cs_esq.color() == Color.NONE:
        andar(0.5)
        wait(10)
    
    # Detecta cor usando HUE no sensor direito
    cor_detectada = get_cor_confiavel(cs_dir)
    
    # Executa ação correspondente à cor
    if cor_detectada in map_train_III:
        map_train_III[cor_detectada]()


def detectar_e_empurrar_TIV():
    """
    Detecta a cor do carrinho na estação IV usando sensor direito
    e empurra para a posição correta, depois executa route_VI.
    """
    wait(10)
    # Aguarda até detectar alguma cor
    while cs_dir.color() == Color.NONE and cs_esq.color() == Color.NONE:
        andar(0.5)
        wait(10)
    
    # Detecta cor usando HUE no sensor direito
    cor_detectada = get_cor_confiavel(cs_dir)
    
    # Executa ação correspondente à cor
    if cor_detectada in map_train_IV:
        map_train_IV[cor_detectada]()

