from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from pybricks.parameters import Axis

hub = PrimeHub(top_side=Axis.X, front_side=Axis.Z)
claw = Motor(Port.A, Direction.CLOCKWISE)
claw.brake()
me = Motor(Port.F, Direction.COUNTERCLOCKWISE)
md = Motor(Port.C)
cancela = Motor(Port.B)
cs_dir = ColorSensor(Port.D)
cs_esq = ColorSensor(Port.E)

drive_base = DriveBase(me, md, 54, 115) 
drive_base.use_gyro(True)

def _wrap_angle(error: float) -> float:
    """Normaliza erro de heading para o intervalo [-180, 180]."""
    while error > 180:
        error -= 360
    while error < -180:
        error += 360
    return error

def andar(dist, velocidade=250, kp=3.0, ki=0.03, kd=0.8, limite_giro=120):
    """
    Movimento retilíneo com correção PID usando IMU.
    Se o robô for empurrado, ele corrige o heading e mantém a rota.
    dist em cm (compatível com o uso original).
    """
    alvo_mm = dist * 10
    direcao = 1 if alvo_mm >= 0 else -1
    velocidade = abs(velocidade) * direcao

    drive_base.settings(350, 350, 220, 220)
    drive_base.reset()

    heading_alvo = hub.imu.heading()
    integral = 0.0
    erro_anterior = 0.0

    while direcao * drive_base.distance() < direcao * alvo_mm:
        erro = _wrap_angle(heading_alvo - hub.imu.heading())
        integral = max(min(integral + erro, 500), -500)  # evita windup
        deriv = erro - erro_anterior

        correcao = kp * erro + ki * integral + kd * deriv
        correcao = max(min(correcao, limite_giro), -limite_giro)

        drive_base.drive(velocidade, correcao)

        erro_anterior = erro
        wait(10)

    drive_base.stop

def turn(radius, angle):
    drive_base.settings(200, 200, 200, 200)
    drive_base.curve(radius, angle)

def rotate(graus, velocidade=None):
    """
    Giro com controle PID usando IMU para maior precisão.
    Otimizado para giros à esquerda (negativos) e direita (positivos).
    graus: alvo relativo ao heading atual.
    velocidade: parâmetro opcional para compatibilidade (ignorado).
    """
    # Ajustes diferentes para esquerda (negativo) e direita (positivo)
    if graus < 0:  # Giro à esquerda - mais preciso
        kp, ki, kd = 4.0, 0, 1.5
        limite_giro = 300
        tolerancia = 0.6
    else:  # Giro à direita
        kp, ki, kd = 4.0, 0, 1.2
        limite_giro = 320
        tolerancia = 0.8

    heading_atual = hub.imu.heading()
    alvo = heading_atual + graus
    
    # Normaliza alvo para [-180, 180]
    while alvo > 180:
        alvo -= 360
    while alvo < -180:
        alvo += 360

    integral = 0.0
    erro_anterior = 0.0
    contador_estavel = 0
    max_estavel = 3  # precisa estar estável por 3 iterações

    drive_base.stop()
    wait(50)  # pequena pausa para garantir que parou

    while True:
        heading_atual = hub.imu.heading()
        erro = _wrap_angle(alvo - heading_atual)
        
        # Verifica se está dentro da tolerância
        if abs(erro) <= tolerancia:
            contador_estavel += 1
            if contador_estavel >= max_estavel:
                break
        else:
            contador_estavel = 0

        # Calcula PID
        integral = max(min(integral + erro, 500), -500)
        deriv = erro - erro_anterior

        correcao = kp * erro + ki * integral + kd * deriv
        correcao = max(min(correcao, limite_giro), -limite_giro)

        drive_base.drive(0, correcao)

        erro_anterior = erro
        wait(10)

    drive_base.stop
    wait(100)  # aguarda estabilização final
    
    # Correção final se necessário (overshoot pequeno)
    heading_final = hub.imu.heading()
    erro_final = _wrap_angle(alvo - heading_final)
    if abs(erro_final) > tolerancia * 1.5:  # se ainda estiver muito fora
        drive_base.turn(erro_final)
        wait(50)
    
    drive_base.stop

def _bt_pressionado() -> bool:
    return Button.BLUETOOTH in hub.buttons.pressed()

def esperar_bt_press_release(msg: str | None = None):
    if msg:
        print(msg)
    while not _bt_pressionado():
        wait(50)
    while _bt_pressionado():
        wait(50)

def aguardar_calibrar_imu():
    """
    Clique 1 (Bluetooth): calibra IMU, sinaliza laranja->verde.
    Clique 2 (Bluetooth): inicia missão, LED azul.
    """
    esperar_bt_press_release("Pressione Bluetooth para calibrar IMU")
    hub.light.on(Color.ORANGE)
    print("Calibrando IMU...")
    while not hub.imu.ready():
        wait(50)
    hub.imu.reset_heading(0)
    hub.light.on(Color.GREEN)
    print("IMU calibrada. Pressione Bluetooth para iniciar")
    esperar_bt_press_release()
    hub.light.on(Color.BLUE)
    print("Iniciando missão...")

def parar_se_bluetooth() -> bool:
    """Detecta pedido de parada via botão Bluetooth."""
    if _bt_pressionado():
        print("Parada solicitada pelo botão Bluetooth.")
        hub.light.on(Color.RED)
        return True
    return False

def estabilizar_imu(tempo_espera=200, tolerancia=0.5, max_tentativas=20):
    """
    Aguarda a IMU se estabilizar após movimentos de motores.
    Útil após operações de garra, cancela, etc.
    """
    wait(tempo_espera)  # aguarda vibrações iniciais cessarem
    
    heading_inicial = hub.imu.heading()
    tentativas = 0
    
    while tentativas < max_tentativas:
        wait(50)
        heading_atual = hub.imu.heading()
        variacao = abs(_wrap_angle(heading_atual - heading_inicial))
        
        if variacao <= tolerancia:
            # IMU estável, mantém o heading atual como referência
            return
        
        heading_inicial = heading_atual
        tentativas += 1
    
    # Se não estabilizou completamente, pelo menos aguardou o tempo mínimo
    print(f"IMU: estabilização parcial após {max_tentativas} tentativas")

