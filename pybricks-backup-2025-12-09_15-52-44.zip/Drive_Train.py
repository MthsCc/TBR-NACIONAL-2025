from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from pybricks.parameters import Axis

hub = PrimeHub(top_side=Axis.X, front_side=Axis.Z)
claw = Motor(Port.A, Direction.CLOCKWISE)
claw.brake
me = Motor(Port.F, Direction.COUNTERCLOCKWISE)
md = Motor(Port.C)
cancela = Motor(Port.B)
cs_dir = ColorSensor(Port.D)
cs_esq = ColorSensor(Port.E)

drive_base = DriveBase(me, md, 54, 115) 
drive_base.use_gyro(True)


def _wrap_angle(error: float) -> float:
    """Normaliza erro de heading para o intervalo [-180, 180]."""
    while error > 180:
        error -= 360
    while error < -180:
        error += 360
    return error


def andar(dist, velocidade=250, kp=3.0, ki=0.03, kd=0.8, limite_giro=120):
    """
    Movimento retilíneo com correção PID usando IMU.
    Se o robô for empurrado, ele corrige o heading e mantém a rota.
    dist em cm (compatível com o uso original).
    """
    alvo_mm = dist * 10
    direcao = 1 if alvo_mm >= 0 else -1
    velocidade = abs(velocidade) * direcao

    drive_base.reset()

    heading_alvo = hub.imu.heading()
    integral = 0.0
    erro_anterior = 0.0

    while direcao * drive_base.distance() < direcao * alvo_mm:
        erro = _wrap_angle(heading_alvo - hub.imu.heading())
        integral = max(min(integral + erro, 500), -500)  # evita windup
        deriv = erro - erro_anterior

        correcao = kp * erro + ki * integral + kd * deriv
        correcao = max(min(correcao, limite_giro), -limite_giro)

        drive_base.drive(velocidade, correcao)

        erro_anterior = erro
        wait(10)

    drive_base.stop


def turn(radius, angle):
    drive_base.settings(200, 200, 200, 200)
    drive_base.curve(radius, angle)

def rotate(graus, velocidade=None):
    kp, ki, kd = 4.0, 0.04, 1.2
    limite_giro = 320  # deg/s
    tolerancia = 0.8   # deg

    alvo = hub.imu.heading() + graus
    # normaliza alvo para [-180, 180] relativo ao 0
    while alvo > 180:
        alvo -= 360
    while alvo < -180:
        alvo += 360

    integral = 0.0
    erro_anterior = 0.0

    drive_base.stop()

    while True:
        erro = _wrap_angle(alvo - hub.imu.heading())
        if abs(erro) <= tolerancia:
            break

        integral = max(min(integral + erro, 500), -500)
        deriv = erro - erro_anterior

        correcao = kp * erro + ki * integral + kd * deriv
        correcao = max(min(correcao, limite_giro), -limite_giro)

        drive_base.drive(0, correcao)

        erro_anterior = erro
        wait(10)

    drive_base.stop


def _bt_pressionado() -> bool:
    return Button.BLUETOOTH in hub.buttons.pressed()


def esperar_bt_press_release(msg: str | None = None):
    if msg:
        print(msg)
    while not _bt_pressionado():
        wait(50)
    while _bt_pressionado():
        wait(50)


def aguardar_calibrar_imu():
    """
    Clique 1 (Bluetooth): calibra IMU, sinaliza laranja->verde.
    Clique 2 (Bluetooth): inicia missão, LED azul.
    """
    esperar_bt_press_release("Pressione Bluetooth para calibrar IMU")
    hub.light.on(Color.ORANGE)
    print("Calibrando IMU...")
    while not hub.imu.ready():
        wait(50)
    hub.imu.reset_heading(0)
    hub.light.on(Color.GREEN)
    print("IMU calibrada. Pressione Bluetooth para iniciar")
    esperar_bt_press_release()
    hub.light.on(Color.BLUE)
    print("Iniciando missão...")


def parar_se_bluetooth() -> bool:
    """Detecta pedido de parada via botão Bluetooth."""
    if _bt_pressionado():
        print("Parada solicitada pelo botão Bluetooth.")
        hub.light.on(Color.RED)
        return True
    return False
