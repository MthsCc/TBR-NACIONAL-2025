from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.robotics import DriveBase
from pybricks.parameters import Port, Axis, Direction
from pybricks.tools import wait
from Drive_Train import rotate, andar, aguardar_calibrar_imu, parar_se_bluetooth, parar_se_bluetooth


hub = PrimeHub(top_side=Axis.X, front_side=Axis.Z)

aguardar_calibrar_imu()  # clique 1 calibra IMU (laranja->verde), clique 2 inicia (azul)
andar(30)
wait(200)
rotate(-90)
wait(200)
andar(50)


