from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.robotics import DriveBase
from pybricks.parameters import Button, Color, Port, Direction, Axis # <-- IMPORTANTE: Adicionei Axis
from pybricks.tools import wait

# --- CORREÇÃO DE ORIENTAÇÃO (Eixo Z Negativo) ---
# top_side=Axis.X: O lado USB/Portas (Eixo X) é o novo Topo (Eixo de rotação/Heading).
# front_side=-Axis.Z: O lado do Botão (Eixo Z) é a nova Frente, mas invertido.
hub = PrimeHub(top_side=Axis.X, front_side=-Axis.Z) 
# ------------------------------------------------

# --- CONFIGURAÇÃO DO ROBÔ ---
DIAMETRO_RODA = 56 
DISTANCIA_EIXOS = 114

motor_esq = Motor(Port.A, Direction.COUNTERCLOCKWISE) 
motor_dir = Motor(Port.B)
robot = DriveBase(motor_esq, motor_dir, DIAMETRO_RODA, DISTANCIA_EIXOS) 

# --- VARIÁVEIS PID PARA CONTROLE DE HEADING ---
ganho_p = 1.9
ganho_i = 0
ganho_d = 0.9
erro_acumulado = 0
erro_anterior = 0
INTEGRAL_MAX = 150       
ANGULO_TOLERANCIA = 0.5 

# --- VARIÁVEIS DE CONTROLE ---
modo = 0                 
VELOCIDADE_PADRAO = 150 
angulo_alvo = 0

# --- FUNÇÃO AUXILIAR PARA RESETAR (Ainda não usada no bloco START) ---
def zerar_distancia_percorrida():
    """Zera os encoders dos motores esquerdo e direito."""
    motor_esq.reset_angle(0)
    motor_dir.reset_angle(0)

hub.display.text("---")
hub.light.on(Color.ORANGE)

print("Iniciado. Seta Esquerda (MODE).")

while True:
    
    # MUDANÇA DE MODO: START/RUN (Seta Esquerda)
    if Button.LEFT in hub.buttons.pressed() and modo == 0:
        robot.stop()
        
        # --- RESET COMPLETO DE SENSORES E ODOMETRIA ---
        hub.imu.reset_heading(0)
        # O reset da distância (zerar_distancia_percorrida()) seria chamado aqui.
        erro_acumulado = 0
        erro_anterior = 0
        
        modo = 2 # Começa direto no modo de exploração
        hub.display.text("RUN")
        hub.light.on(Color.GREEN)
        print("\n--- INÍCIO DA EXPLORAÇÃO CONTÍNUA ---")

    # CICLAGEM DOS OUTROS MODOS (Incluindo 1)
    elif Button.LEFT in hub.buttons.pressed() and modo != 0:
        robot.stop()
        modo += 1
        if modo > 2: # <--- CICLO AGORA VAI DE 0 -> 1 -> 2 -> 0
            modo = 0
        
        hub.display.text(str(modo))
        print(f"Modo alterado para: {modo}")

    # MUDANÇA DE MODO: STOP MANUAL (Botão Central)
    if Button.CENTER in hub.buttons.pressed() and modo != 0:
        robot.stop()
        modo = 0 
        hub.display.text("STOP")
        hub.light.on(Color.RED)
        print("--- PARADA MANUAL (CENTRAL) ---")
        
    # STOP DE EMERGÊNCIA (Seta Direita)
    if Button.RIGHT in hub.buttons.pressed():
        robot.stop() 
        hub.display.text("FIM")
        hub.light.on(Color.RED)
        break
    
    
    if modo == 0:
        hub.light.on(Color.ORANGE)
        
    elif modo == 1:
        # Modo de Verificação Simples (Exemplo)
        hub.display.text("IMU")
        
    elif modo == 2:
        # MODO DE EXPLORAÇÃO (Controle PID e Rastreamento de Distância)
        
        # Lógica PID
        # Esta chamada agora está ajustada para a nova orientação!
        angulo_atual = hub.imu.heading() 
        erro_angular = angulo_atual - angulo_alvo
        
        # A lógica PID original é mantida, pois o Pybricks corrigiu os eixos.
        if abs(erro_angular) > ANGULO_TOLERANCIA:
            erro_acumulado += erro_angular  
        erro_acumulado = max(min(erro_acumulado, INTEGRAL_MAX), -INTEGRAL_MAX)
        erro_derivativo = erro_angular - erro_anterior
        
        componente_p = erro_angular * ganho_p
        componente_i = erro_acumulado * ganho_i
        componente_d = erro_derivativo * ganho_d
        
        correcao_de_giro = componente_p + componente_i + componente_d
        erro_anterior = erro_angular 
        
        # Comando de movimento
        robot.drive(VELOCIDADE_PADRAO, -correcao_de_giro) 
        
        # Rastreamento da Distância
        distancia = robot.distance() 
        print(f"Distância percorrida: {distancia:.1f} mm") 
        hub.display.text(f"D={distancia:.0f}")
        
    wait(10)

# --- FINALIZAÇÃO DO PROGRAMA ---
robot.stop()
hub.light.off()
print("Programa encerrado.")