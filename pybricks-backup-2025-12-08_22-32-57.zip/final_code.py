from pybricks.hubs import PrimeHub
from pybricks.pupdevices import ColorSensor
from pybricks.parameters import Color
from pybricks.tools import wait

from Drive_Train import andar, cs_dir, cs_esq, rotate, hub
from consts import deposit, volta_direita, volta_esquerda
from Rota_1 import boxG_amarelo, boxG_azul, boxG_cinza, boxG_verde, route_VI_amarelo, route_VI_azul, route_VI_cinza, route_VI_verde, route_I, route_II, route_III, route_IV, route_V, train_I, train_III, park, boxB_

PRETO_MAX = 15
AMARELO_MIN = 60
HUE_SATURACAO_MIN = 20

HUE_AZUL_MIN = 200
HUE_AZUL_MAX = 240 
HUE_VERDE_MIN = 120
HUE_VERDE_MAX = 180 

# Inicializa a IMU
hub.imu.reset_heading(0)

def get_cor_confiavel(sensor: ColorSensor) -> Color:
    intensidade_reflexao = sensor.reflection()
    hsv = sensor.hsv() # (Hue, Saturation, Value)
    hue = hsv[0]
    saturation = hsv[1]
    
    cor_detectada = Color.NONE

    if intensidade_reflexao >= AMARELO_MIN:
        if hue > 40 and hue < 70 and saturation > HUE_SATURACAO_MIN:
            cor_detectada = Color.YELLOW
        else:
            cor_detectada = Color.GRAY
    
    elif intensidade_reflexao <= PRETO_MAX:
        cor_detectada = Color.BLACK

    elif hue >= HUE_AZUL_MIN and hue <= HUE_AZUL_MAX and saturation > HUE_SATURACAO_MIN:
        cor_detectada = Color.BLUE
    
    elif hue >= HUE_VERDE_MIN and hue <= HUE_VERDE_MAX and saturation > HUE_SATURACAO_MIN:
        cor_detectada = Color.GREEN
    
    elif intensidade_reflexao > PRETO_MAX and intensidade_reflexao < AMARELO_MIN:
        cor_detectada = Color.GRAY
        
    print(f"Cor Detectada: {cor_detectada} (Hue: {hue}, Ref: {intensidade_reflexao}, Heading: {hub.imu.heading():.1f}°)")
    
    return cor_detectada


def azul_TI(): 
    deposit()
    andar(46)
    wait(500)
    andar(-50)
    volta_esquerda()

def amarelo_TI(): 
    andar(25)
    andar(-29)
    volta_esquerda()

def cinza_TI(): 
    andar(15)
    andar(-19)
    volta_esquerda()

def verde_TI(): 
    andar(35)
    andar(-39)
    volta_esquerda()

map_train_I = {
    Color.BLUE: azul_TI,
    Color.YELLOW: amarelo_TI, 
    Color.GRAY: cinza_TI,
    Color.GREEN: verde_TI,
}


def azul_TII(): 
    andar(45)
    wait(500)
    andar(-47)
    volta_direita()
    boxG_azul()

def amarelo_TII(): 
    andar(24)
    wait(300)
    andar(-26)
    wait(200)
    volta_direita()
    boxG_amarelo()

def cinza_TII(): 
    andar(13)
    wait(100)
    andar(-15)
    wait(100)
    volta_direita()
    boxG_cinza()

def verde_TII(): 
    andar(34)
    andar(-36)
    volta_direita()
    boxG_verde()

map_train_II = {
    Color.BLUE: azul_TII,
    Color.YELLOW:amarelo_TII,
    Color.GRAY: cinza_TII,
    Color.GREEN: verde_TII,
}


def azul_TIII(): 
    andar(42.5)
    wait(500)
    andar(-44.5)
    volta_direita()

def amarelo_TIII(): 
    andar(25)
    andar(-27)
    volta_direita()

def cinza_TIII(): 
    andar(15)
    andar(-17)
    volta_direita()

def verde_TIII(): 
    andar(35)
    andar(-37)
    volta_direita()

map_train_III = {
    Color.BLUE: azul_TIII,
    Color.YELLOW: amarelo_TIII,
    Color.GRAY: cinza_TIII,
    Color.GREEN: verde_TIII,
}


def azul_TIV(): 
    andar(45)
    wait(500)
    andar(-47)
    volta_direita()
    wait(200)
    route_VI_azul()

def amarelo_TIV(): 
    andar(25)
    andar(-27)
    volta_direita()
    wait(200)
    route_VI_amarelo()

def cinza_TIV(): 
    andar(15)
    andar(-17)
    volta_direita()
    wait(200)
    route_VI_cinza()

def verde_TIV(): 
    andar(35)
    andar(-37)
    volta_direita()
    wait(200)
    route_VI_verde()

map_train_IV = {
    Color.BLUE: azul_TIV,
    Color.YELLOW: amarelo_TIV,
    Color.GRAY: cinza_TIV,
    Color.GREEN: verde_TIV,
}


def detect_train_I():
    wait(10) 
    while cs_dir.color() == Color.NONE and cs_esq.color() == Color.NONE:
        andar(0.5)
        wait(10)
    cor_detectada = get_cor_confiavel(cs_esq)
    if cor_detectada in map_train_I:
        map_train_I[cor_detectada]()

def detect_train_II():
    wait(10)
    while cs_dir.color() == Color.NONE and cs_esq.color() == Color.NONE:
        andar(0.5)
        wait(10)
    cor_detectada = get_cor_confiavel(cs_dir)
    if cor_detectada in map_train_II:
        map_train_II[cor_detectada]()

def detect_train_III():
    wait(10)
    while cs_dir.color() == Color.NONE and cs_esq.color() == Color.NONE:
        andar(0.5)
        wait(10)
    cor_detectada = get_cor_confiavel(cs_dir)
    if cor_detectada in map_train_III:
        map_train_III[cor_detectada]()

def detect_train_IV():
    wait(10)
    while cs_dir.color() == Color.NONE and cs_esq.color() == Color.NONE:
        andar(0.5)
        wait(10)
    cor_detectada = get_cor_confiavel(cs_dir)
    if cor_detectada in map_train_IV:
        map_train_IV[cor_detectada]()


route_I()
wait(400)
train_I()
detect_train_I()

route_II()
wait(300)

route_III()
wait(400)
detect_train_II()

route_IV() 
train_III()
detect_train_III()
route_V()
detect_train_IV()
boxB_()
park()