from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from Drive_Train import andar, rotate, turn
from consts import Open, close, upper, low, mid, deposit, cancela_esquerda, cancela_direita, volta_direita, volta_esquerda, direita_direto, esquerda_direto
from Rota_1 import route_VI_amarelo, route_VI_azul, route_VI_cinza, route_VI_verde, 
from Rota_1 import route_V, park


hub = PrimeHub()

sensor_cor_real = ColorSensor(Port.E) 


def TesteCor(sensor) -> tuple[int, int, int]:
    intensidade_reflexao = sensor.reflection()
    hsv = sensor.hsv()
    hue = hsv[0]
    value = hsv[2]
    
    return (hue, intensidade_reflexao, value)

while True:
    resultado_cor = TesteCor(sensor_cor_real)
    
    hue = resultado_cor[0]
    reflexao = resultado_cor[1]
    value = resultado_cor[2]

    print(f"HUE: {hue}, Reflexão: {reflexao}, Value: {value}")
    
    if hue > 220 and hue <280:
        print("Azul")
    elif hue > 40 and hue < 100:
        print("Amarelo")
    elif hue > 125 and hue < 200:
        print("Verde")
    elif hue > 305 and hue < 360:
        print("Cinza")
    else:
        print("Cor desconhecida")

    battery_voltage = hub.battery.voltage()
    print("Nivel da bateria", battery_voltage / 1000, "V")
    wait(1000)